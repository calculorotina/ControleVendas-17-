﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ControleVendas.pt.projeto.model
{
    public class clientes
    {

        public int codigo { get; set; }

        public string nome { get; set; }

        public string morada { get; set; }

        public string cp { get; set; }

        public string localidade { get; set; }

        public string telefone { get; set; }

        public string telemovel { get; set; }

        public string email { get; set; }

        public string condpag { get; set; }

        public string modopag { get; set; }

        public int id { get; set; }

    }
}
