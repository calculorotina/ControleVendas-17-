﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ControleVendas.pt.projeto.model
{
    public class Produtos
    {
        public string  codigo { get; set; }
        public string descricao { get; set; }
        public string  preco { get; set; }
        public string quantidade { get; set; }
        public string familia { get; set; }
        public string for_id { get; set; }

    }
}
