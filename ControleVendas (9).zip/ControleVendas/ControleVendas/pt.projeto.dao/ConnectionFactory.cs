﻿namespace ControleVendas.pt.projeto.dao
{
    internal class ConnectionFactory
    {
        public ConnectionFactory()
        {
        }
    }
}